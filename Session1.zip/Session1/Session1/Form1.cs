namespace Session1
{
    public partial class Grant_JoyceQuestion1 : Form
    {
        public Grant_JoyceQuestion1()
        {
            InitializeComponent();
        }
    }
}
